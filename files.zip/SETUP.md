# TechPulse SuperBot — Setup Guide

## What This Bot Does
Monitors **28 RSS feeds** across 4 emerging tech categories and pushes
only relevant articles to your Telegram — every 30 minutes automatically.

**Categories monitored:**
- 🔗 Blockchain / Web3 / DeFi / Crypto
- 🤖 AI & Machine Learning (all industries)
- 💳 Fintech (payments, lending, neobanks, insurtech)
- 📈 Trading & Investing Tech

---

## Step 1 — Create Your Telegram Bot

1. Open Telegram → search **@BotFather**
2. Send `/newbot`
3. Name it: e.g. `TechPulse SuperBot`
4. Username: e.g. `techpulse_super_bot`
5. Copy the token it gives you

---

## Step 2 — Get Your Chat ID

1. Search **@userinfobot** on Telegram
2. Send it any message
3. It replies with your Chat ID (a number like `987654321`)

---

## Step 3 — Install & Configure

```bash
pip install -r requirements.txt
```

Create a `.env` file in the same folder:
```
TELEGRAM_BOT_TOKEN=your_token_here
TELEGRAM_CHAT_ID=your_chat_id_here
CHECK_INTERVAL=1800
```

---

## Step 4 — Run It

```bash
export $(cat .env | xargs) && python bot.py
```

You will get a startup message in Telegram. Done.

---

## Step 5 — Keep It Running 24/7 (Free)

**Railway.app (recommended):**
1. Push the folder to a GitHub repo
2. Go to railway.app → New Project → Deploy from GitHub
3. Add env variables in Railway dashboard
4. Runs forever for free

---

## Telegram Commands

| Command   | What it does                          |
|-----------|---------------------------------------|
| /latest   | Force-check all feeds right now       |
| /pause    | Pause automatic updates               |
| /resume   | Resume automatic updates              |
| /status   | Show bot state and feed count         |

---

## Adding More Sources

Open `bot.py` and add to the `FEEDS` list:
```python
{"url": "https://your-rss-feed-url/feed", "cat": "🤖 AI & Machine Learning"},
```

## Adding Keywords

Open `bot.py` and add to the `KEYWORDS` dict under the right category:
```python
"🤖 AI & Machine Learning": [
    "your keyword here", ...
]
```

---

## Troubleshooting

| Problem             | Fix                                         |
|---------------------|---------------------------------------------|
| Bot sends nothing   | Add broader keywords, or lower the filter   |
| Error 401           | Wrong bot token                             |
| Error 400           | Wrong chat ID                               |
| Feed not loading    | RSS URL may be dead — try another source    |

---

Built for Arjun | TechPulse SuperBot v2.0
