"""
TechPulse SuperBot
Monitors 28 RSS feeds across 4 emerging tech categories and pushes
relevant updates to your Telegram in near real-time.

Categories:
  🔗 Blockchain / Web3 / DeFi / Crypto
  🤖 AI & Machine Learning
  💳 Fintech (payments, lending, neobanks, insurtech)
  📈 Trading & Investing Tech
"""

import asyncio
import feedparser
import hashlib
import json
import logging
import os
import re
from datetime import datetime
from pathlib import Path

from telegram import Bot, Update
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes

# ─────────────────────────────────────────────
# CONFIG  —  set these in your .env file
# ─────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID",   "YOUR_CHAT_ID_HERE")
CHECK_INTERVAL     = int(os.getenv("CHECK_INTERVAL",  "1800"))   # 30 min default
SEEN_FILE          = Path("seen_articles.json")

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(message)s",
    level=logging.INFO
)
log = logging.getLogger(__name__)

# Global state
BOT_PAUSED = False

# ─────────────────────────────────────────────
# 28 RSS FEEDS — 4 categories
# ─────────────────────────────────────────────
FEEDS = [

    # ── 🔗 Blockchain / Web3 / DeFi / Crypto ─────────────────────────────
    {"url": "https://cointelegraph.com/rss",                                    "cat": "🔗 Blockchain / Web3 / Crypto"},
    {"url": "https://coindesk.com/arc/outboundfeeds/rss/",                      "cat": "🔗 Blockchain / Web3 / Crypto"},
    {"url": "https://decrypt.co/feed",                                          "cat": "🔗 Blockchain / Web3 / Crypto"},
    {"url": "https://thedefiant.io/api/feed",                                   "cat": "🔗 Blockchain / Web3 / Crypto"},
    {"url": "https://www.reddit.com/r/ethereum/.rss",                           "cat": "🔗 Blockchain / Web3 / Crypto"},
    {"url": "https://www.reddit.com/r/defi/.rss",                               "cat": "🔗 Blockchain / Web3 / Crypto"},
    {"url": "https://www.reddit.com/r/web3/.rss",                               "cat": "🔗 Blockchain / Web3 / Crypto"},

    # ── 🤖 AI & Machine Learning ──────────────────────────────────────────
    {"url": "https://towardsdatascience.com/feed",                              "cat": "🤖 AI & Machine Learning"},
    {"url": "https://www.artificialintelligence-news.com/feed/",                "cat": "🤖 AI & Machine Learning"},
    {"url": "https://venturebeat.com/category/ai/feed/",                        "cat": "🤖 AI & Machine Learning"},
    {"url": "https://feeds.feedburner.com/aidaily",                             "cat": "🤖 AI & Machine Learning"},
    {"url": "https://www.reddit.com/r/artificial/.rss",                         "cat": "🤖 AI & Machine Learning"},
    {"url": "https://www.reddit.com/r/MachineLearning/.rss",                    "cat": "🤖 AI & Machine Learning"},
    {"url": "https://techcrunch.com/category/artificial-intelligence/feed/",    "cat": "🤖 AI & Machine Learning"},

    # ── 💳 Fintech ────────────────────────────────────────────────────────
    {"url": "https://www.finextra.com/rss/headlines.aspx",                      "cat": "💳 Fintech"},
    {"url": "https://fintechmagazine.com/rss.xml",                              "cat": "💳 Fintech"},
    {"url": "https://techcrunch.com/category/fintech/feed/",                    "cat": "💳 Fintech"},
    {"url": "https://www.bankingtech.com/feed/",                                "cat": "💳 Fintech"},
    {"url": "https://thefintechtimes.com/feed/",                                "cat": "💳 Fintech"},
    {"url": "https://www.pymnts.com/feed/",                                     "cat": "💳 Fintech"},
    {"url": "https://www.reddit.com/r/fintech/.rss",                            "cat": "💳 Fintech"},

    # ── 📈 Trading & Investing Tech ───────────────────────────────────────
    {"url": "https://quantocracy.com/feed/",                                    "cat": "📈 Trading & Investing Tech"},
    {"url": "https://www.quantstart.com/articles/feed/",                        "cat": "📈 Trading & Investing Tech"},
    {"url": "https://alpaca.markets/blog/feed/",                                "cat": "📈 Trading & Investing Tech"},
    {"url": "https://robotwealth.com/feed/",                                    "cat": "📈 Trading & Investing Tech"},
    {"url": "https://www.tradingview.com/blog/en/feed/",                        "cat": "📈 Trading & Investing Tech"},
    {"url": "https://www.reddit.com/r/algotrading/.rss",                        "cat": "📈 Trading & Investing Tech"},
    {"url": "https://www.reddit.com/r/quant/.rss",                              "cat": "📈 Trading & Investing Tech"},
]

# ─────────────────────────────────────────────
# KEYWORDS — one filter layer to remove truly
# off-topic posts (especially from Reddit/HN)
# ─────────────────────────────────────────────
KEYWORDS = {
    "🔗 Blockchain / Web3 / Crypto": [
        "blockchain", "crypto", "bitcoin", "ethereum", "defi", "web3", "nft",
        "token", "wallet", "protocol", "smart contract", "dao", "layer 2",
        "polygon", "solana", "avalanche", "stablecoin", "yield", "dex", "cefi",
        "airdrop", "bridge", "on-chain", "zkp", "zero knowledge",
    ],
    "🤖 AI & Machine Learning": [
        "ai", "artificial intelligence", "machine learning", "deep learning",
        "neural network", "llm", "gpt", "gemini", "claude", "mistral", "llama",
        "generative ai", "nlp", "computer vision", "model", "dataset",
        "fine-tuning", "prompt", "agent", "automation", "openai", "anthropic",
        "hugging face", "transformer", "diffusion",
    ],
    "💳 Fintech": [
        "fintech", "neobank", "payment", "lending", "insurtech", "regtech",
        "wealthtech", "open banking", "embedded finance", "bnpl", "digital bank",
        "kyc", "aml", "compliance", "remittance", "credit", "card", "wallet",
        "stripe", "plaid", "revolut", "chime", "nubank", "paytm", "razorpay",
    ],
    "📈 Trading & Investing Tech": [
        "trading", "investing", "quant", "algo", "backtesting", "strategy",
        "broker", "api", "portfolio", "hedge fund", "retail trading",
        "market data", "order execution", "risk", "python trading",
        "systematic", "momentum", "signal", "factor", "alpha",
    ],
}

# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def load_seen() -> set:
    if SEEN_FILE.exists():
        return set(json.loads(SEEN_FILE.read_text()))
    return set()

def save_seen(seen: set):
    SEEN_FILE.write_text(json.dumps(list(seen)))

def article_id(entry) -> str:
    key = getattr(entry, "link", "") or getattr(entry, "title", "") or str(entry)
    return hashlib.md5(key.encode()).hexdigest()

def is_relevant(title: str, summary: str, category: str) -> bool:
    text = (title + " " + summary).lower()
    return any(kw in text for kw in KEYWORDS.get(category, []))

def clean_html(raw: str) -> str:
    return re.sub(r"<[^>]+>", "", raw or "").strip()[:280]

def escape_md(text: str) -> str:
    """Escape special characters for Telegram MarkdownV2."""
    special = r"\_*[]()~`>#+-=|{}.!"
    return re.sub(r"([" + re.escape(special) + r"])", r"\\\1", text)

def format_message(entry, category: str) -> str:
    title   = getattr(entry, "title",   "No title")
    link    = getattr(entry, "link",    "")
    summary = clean_html(getattr(entry, "summary", ""))
    pub     = getattr(entry, "published", "")

    lines = [f"*{category}*", "", f"📌 *{title}*"]
    if summary:
        lines.append(f"\n_{summary}_")
    if pub:
        lines += ["", f"🕐 {pub}"]
    if link:
        lines += ["", f"[→ Read article]({link})"]

    return "\n".join(lines)

# ─────────────────────────────────────────────
# FEED CHECKER
# ─────────────────────────────────────────────

async def check_feeds(bot: Bot, seen: set) -> set:
    if BOT_PAUSED:
        log.info("Bot is paused — skipping feed check.")
        return seen

    new_count = 0

    for feed_cfg in FEEDS:
        url = feed_cfg["url"]
        cat = feed_cfg["cat"]

        try:
            parsed  = feedparser.parse(url)
            entries = parsed.entries[:8]   # latest 8 per feed
        except Exception as e:
            log.warning(f"Failed to parse {url}: {e}")
            continue

        for entry in entries:
            aid = article_id(entry)
            if aid in seen:
                continue

            title   = getattr(entry, "title",   "")
            summary = clean_html(getattr(entry, "summary", ""))

            if not is_relevant(title, summary, cat):
                seen.add(aid)
                continue

            msg = format_message(entry, cat)
            try:
                await bot.send_message(
                    chat_id=TELEGRAM_CHAT_ID,
                    text=msg,
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=False,
                )
                log.info(f"✅ Sent: {title[:70]}")
                new_count += 1
                await asyncio.sleep(1.5)   # respect Telegram rate limit
            except Exception as e:
                log.error(f"Telegram send failed: {e}")

            seen.add(aid)

    save_seen(seen)
    log.info(f"Cycle done. Sent {new_count} new articles.")
    return seen

# ─────────────────────────────────────────────
# TELEGRAM COMMANDS
# ─────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = (
        "🚀 *TechPulse SuperBot is live\\!*\n\n"
        "Monitoring:\n"
        "• 🔗 Blockchain / Web3 / Crypto\n"
        "• 🤖 AI & Machine Learning\n"
        "• 💳 Fintech\n"
        "• 📈 Trading & Investing Tech\n\n"
        f"Checking every {CHECK_INTERVAL // 60} minutes\\.\n\n"
        "*Commands:*\n"
        "/latest — force check right now\n"
        "/pause — pause updates\n"
        "/resume — resume updates\n"
        "/status — show bot status"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN_V2)

async def cmd_latest(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global BOT_PAUSED
    await update.message.reply_text("🔄 Checking all feeds now — sending new articles...")
    bot  = context.bot
    seen = load_seen()
    seen = await check_feeds(bot, seen)
    await update.message.reply_text("✅ Done. All new articles sent above.")

async def cmd_pause(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global BOT_PAUSED
    BOT_PAUSED = True
    await update.message.reply_text("⏸ Bot paused. Send /resume to restart updates.")

async def cmd_resume(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global BOT_PAUSED
    BOT_PAUSED = False
    await update.message.reply_text("▶️ Bot resumed. Updates are live again.")

async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state  = "⏸ PAUSED" if BOT_PAUSED else "▶️ RUNNING"
    feeds  = len(FEEDS)
    msg = (
        f"*TechPulse Status*\n\n"
        f"State: {state}\n"
        f"Feeds monitored: {feeds}\n"
        f"Check interval: every {CHECK_INTERVAL // 60} min\n"
        f"Last checked: {datetime.now().strftime('%d %b %Y, %H:%M')}"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)

# ─────────────────────────────────────────────
# BACKGROUND FEED LOOP
# ─────────────────────────────────────────────

async def feed_loop(app: Application):
    seen = load_seen()
    bot  = app.bot

    await bot.send_message(
        chat_id=TELEGRAM_CHAT_ID,
        text=(
            "🚀 *TechPulse SuperBot is live\\!\n\n*"
            "Monitoring 28 feeds across:\n"
            "• 🔗 Blockchain / Web3 / Crypto\n"
            "• 🤖 AI & Machine Learning\n"
            "• 💳 Fintech\n"
            "• 📈 Trading & Investing Tech\n\n"
            f"Updates every {CHECK_INTERVAL // 60} min\\. Type /latest to check now\\."
        ),
        parse_mode=ParseMode.MARKDOWN_V2,
    )

    while True:
        seen = await check_feeds(bot, seen)
        await asyncio.sleep(CHECK_INTERVAL)

# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    if TELEGRAM_BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        log.error("❌ Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in your .env file first.")
        return

    app = (
        Application.builder()
        .token(TELEGRAM_BOT_TOKEN)
        .build()
    )

    # Register commands
    app.add_handler(CommandHandler("start",  cmd_start))
    app.add_handler(CommandHandler("latest", cmd_latest))
    app.add_handler(CommandHandler("pause",  cmd_pause))
    app.add_handler(CommandHandler("resume", cmd_resume))
    app.add_handler(CommandHandler("status", cmd_status))

    # Start feed loop as background task
    app.post_init = lambda application: asyncio.get_event_loop().create_task(
        feed_loop(application)
    )

    log.info("Starting TechPulse SuperBot...")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
